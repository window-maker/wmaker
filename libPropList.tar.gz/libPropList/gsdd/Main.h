#ifndef MAIN_H
#define MAIN_H

void BailOut(void);

proplist_t GetDomainNamesFromDir(char *dirname);


#endif /* MAIN_H */
