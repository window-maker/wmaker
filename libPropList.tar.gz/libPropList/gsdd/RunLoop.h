#ifndef RUNLOOP_H
#define RUNLOOP_H

void RunLoop(int sock);

void CleanUpRunLoop(void);

#endif /* RUNLOOP_H */
