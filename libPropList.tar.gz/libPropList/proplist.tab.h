typedef union {
        proplist_t obj;
} YYSTYPE;
#define	STRING	258
#define	DATA	259
#define	ERROR	260
#define	YYERROR_VERBOSE	261
#define	YYDEBUG	262


extern YYSTYPE yylval;
